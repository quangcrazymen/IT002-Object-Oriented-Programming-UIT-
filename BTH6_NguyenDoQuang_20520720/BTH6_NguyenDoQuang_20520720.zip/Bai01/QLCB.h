using namespace std;
class QLCB: public CanBo
{
private:
    vector<CanBo*> dsCanBo;
public:
    void nhap(istream &is);
    void xuat(ostream &os);
    int tinhLuong();
};
