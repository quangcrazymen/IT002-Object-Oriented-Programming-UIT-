#include "DongVat.h"

using namespace std;

void DongVat::xuat(){
    while(1){
        cout<<random(1,4);
    }
    
}