#include <iostream>
#include<vector>
#include "DongVat.cpp"
#include "Bo.cpp"
#include "Cuu.cpp"
#include "De.cpp"

using namespace std;

int main(){
    DongVat a;
    a.xuat();
}