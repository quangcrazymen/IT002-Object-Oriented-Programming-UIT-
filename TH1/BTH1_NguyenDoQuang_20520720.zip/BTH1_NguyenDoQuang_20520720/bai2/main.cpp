#include "SoPhuc.cpp" 
int main(){
    
    return 0;
}