#pragma once
#include "Candidate.h"
#include <vector>
using namespace std;
class TestCandidate{
    private:
        vector<Candidate> listSV;
    public:
        void Nhap();
        void Xuat();
        void XuatLonHon15();
};