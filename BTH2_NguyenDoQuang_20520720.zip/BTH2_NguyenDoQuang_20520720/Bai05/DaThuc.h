#include <memory>

class DaThuc
{
private:
    // Bậc của đa thức:
    int degree;
public:
    DaThuc(/* args */);
    ~DaThuc();
};
