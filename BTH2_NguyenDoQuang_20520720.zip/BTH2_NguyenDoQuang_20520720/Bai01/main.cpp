#include "NhanVien.cpp"
#include<iostream>
#include<string>

using namespace std;
int main(){
//     std::string a = "Nguyen";
//     int num =2;
//     std::string c = to_string(num) + a;
//     cout<<c<<endl;
    NhanVien a("NguyenQuang",1234);
    a.Xuat();
    return 0;
}
