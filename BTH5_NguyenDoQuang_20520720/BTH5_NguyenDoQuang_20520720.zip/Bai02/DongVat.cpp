#include "DongVat.h"

using namespace std;

void DongVat::xuat(){
    cout << "  So con sau mot lua sinh la " << soLuongCon << endl;
    cout << "  So lit sua thu duoc la " << soLitSua << endl;
    
}