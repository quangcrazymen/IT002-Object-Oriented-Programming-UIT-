using namespace std;
class QLNS: public NhanSu
{
private:
    vector<NhanSu*> dsNhanSu;
public:
    void nhap();
    void xuat();
    float tinhLuong();
};
