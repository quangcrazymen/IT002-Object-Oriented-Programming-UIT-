#include "NVQuanLy.h"

long NVQuanly::tinhLuong()
{
    return this->luongCoban + this->soNgayLamViec*200000+TroCap; 
}