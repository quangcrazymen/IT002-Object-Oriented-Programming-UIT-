// Slide 43 Tinh tien luong
#include <iostream>
#include "NhanVien.cpp"
using namespace std;

int main(){
    
}