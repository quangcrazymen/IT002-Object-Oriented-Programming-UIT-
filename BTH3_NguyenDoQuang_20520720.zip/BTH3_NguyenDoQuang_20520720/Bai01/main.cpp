#include<iostream>
#include "HocSinh.cpp"
using namespace std;

int main(){
    HocSinh a;
    a.input();
    a.output();
    return 0;
}